from Core.game_manager import GameManager

if __name__ == "__main__":
    game = GameManager()
    game.play()
