import random

class Boss:
    def __init__(self, name, hp, atk, defense, spd, skill_name, skill_desc):
        self.name = name
        self.max_hp = hp
        self.hp = hp
        self.atk = atk
        self.defense = defense
        self.spd = spd
        self.skill_name = skill_name
        self.skill_desc = skill_desc

    def is_alive(self):
        return self.hp > 0

    def attack(self, target):
        damage = max(self.atk - target.defense, 5)
        target.hp = max(target.hp - damage, 0)
        return damage

    def select_target(self, party):
        living = [char for char in party if char.is_alive()]
        return random.choice(living) if living else None


class InfernalBeast(Boss):
    def __init__(self):
        super().__init__(
            name="Infernal Beast",
            hp=500,
            atk=40,
            defense=15,
            spd=12,
            skill_name="Flame Roar",
            skill_desc="Menyerang semua musuh dengan semburan api."
        )


class ToxicSerpent(Boss):
    def __init__(self):
        super().__init__(
            name="Toxic Serpent",
            hp=450,
            atk=35,
            defense=10,
            spd=18,
            skill_name="Poison Storm",
            skill_desc="Menyebar racun ke seluruh tim."
        )


class VoidReaper(Boss):
    def __init__(self):
        super().__init__(
            name="Void Reaper",
            hp=600,
            atk=45,
            defense=20,
            spd=10,
            skill_name="Chaos Pulse",
            skill_desc="Menyerang acak dan menyebabkan efek negatif."
        )