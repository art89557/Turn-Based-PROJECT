from Core.character import CHARACTERS_POOL
from Core.item import WEAPON_POOL, ITEM_SETS
from Core.stage import STAGES
import random

class GameManager:
    def __init__(self):
        self.stage = None
        self.boss = None
        self.party = []
        self.skill_points = 3
        self.max_skill_points = 5

    def choose_stage(self):
        print("=== Pilih Stage ===")
        for i, (name, stage) in enumerate(STAGES.items(), 1):
            print(f"{i}. {name} - {stage.description}")
        choice = int(input("Masukkan nomor stage: ")) - 1
        stage_key = list(STAGES.keys())[choice]
        self.stage = STAGES[stage_key]
        self.boss = self.stage.get_boss()

    def choose_characters(self):
        print("\nPilih 3 karakter:")
        for i, char in enumerate(CHARACTERS_POOL, 1):
            print(f"{i}. {char.name} ({char.role})")
        while len(self.party) < 3:
            idx = int(input(f"Pilih karakter ke-{len(self.party)+1}: ")) - 1
            self.party.append(CHARACTERS_POOL[idx])

    def play(self):
        self.choose_stage()
        self.choose_characters()
        print("\nPertarungan dimulai!")

        while True:
            print("\n-- Giliran Tim --")
            for char in self.party:
                if not char.is_alive():
                    continue
                print(f"{char.name} - HP: {char.hp}")
                print("1. Basic Attack")
                print("2. Skill")
                if char.energy >= 3:
                    print("3. Special")
                action = int(input("Pilih aksi: "))
                if action == 1:
                    char.basic_attack(self.boss)
                    self.skill_points = min(self.skill_points + 1, self.max_skill_points)
                    char.energy += 1
                elif action == 2 and self.skill_points > 0:
                    char.use_skill(self.boss)
                    self.skill_points -= 1
                    char.energy += 1
                elif action == 3 and char.energy >= 3:
                    char.use_special(self.boss)
                else:
                    print("Aksi tidak valid!")

                if not self.boss.is_alive():
                    print(f"\nBoss {self.boss.name} dikalahkan!")
                    return

            print("\n-- Giliran Boss --")
            target = random.choice([c for c in self.party if c.is_alive()])
            damage = self.boss.atk - target.defense
            target.hp -= max(0, damage)
            print(f"{self.boss.name} menyerang {target.name} dan memberi {max(0, damage)} damage!")

            if all(not c.is_alive() for c in self.party):
                print("Semua karakter tumbang. Game Over.")
                return