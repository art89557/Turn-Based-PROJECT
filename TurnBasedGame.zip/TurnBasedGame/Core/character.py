class Character:
    def __init__(self, name, role, hp, atk, defense, spd):
        self.name = name
        self.role = role
        self.max_hp = hp
        self.hp = hp
        self.atk = atk
        self.defense = defense
        self.spd = spd
        self.energy = 0
        self.weapon = None
        self.item_set = None

    def equip_weapon(self, weapon):
        self.weapon = weapon
        self.atk += weapon.atk_bonus
        self.spd += weapon.spd_bonus

    def equip_item_set(self, item_set):
        self.item_set = item_set
        self.atk += item_set.atk_bonus
        self.defense += item_set.def_bonus
        self.spd += item_set.spd_bonus

    def basic_attack(self, target):
        damage = max(0, self.atk - target.defense)
        target.hp -= damage
        print(f"{self.name} menyerang {target.name} dan memberikan {damage} damage!")
        return damage

    def use_skill(self, target): pass
    def use_special(self, target): pass
    def is_alive(self): return self.hp > 0


# Subclass per role
class DPS(Character):
    def __init__(self, name): 
        super().__init__(name, "DPS", 100, 30, 10, 20)
    def use_skill(self, target):
        damage = max(0, (self.atk * 1.5) - target.defense)
        target.hp -= damage
        print(f"{self.name} menggunakan Skill ke {target.name} dan memberikan {damage} damage!")
    def use_special(self, target):
        if self.energy >= 3:
            damage = max(0, (self.atk * 2.5) - target.defense)
            target.hp -= damage
            self.energy = 0
            print(f"{self.name} menggunakan SPECIAL ke {target.name} dan memberikan {damage} damage!")
        else:
            print(f"{self.name} belum cukup energi!")

class SubDPS(Character):
    def __init__(self, name): 
        super().__init__(name, "SubDPS", 90, 25, 10, 25)
    def use_skill(self, target):
        damage = max(0, (self.atk * 1.2) - target.defense)
        target.hp -= damage
        print(f"{self.name} menyerang cepat ke {target.name}, memberikan {damage} damage!")
    def use_special(self, target):
        if self.energy >= 3:
            damage = max(0, (self.atk * 2.0) - target.defense)
            target.hp -= damage
            self.energy = 0
            print(f"{self.name} mengeluarkan SPECIAL damage ke {target.name} sebesar {damage}!")

class Tank(Character):
    def __init__(self, name): 
        super().__init__(name, "Tank", 150, 15, 30, 10)
    def use_skill(self, target):
        shield = self.defense * 0.5
        self.hp = min(self.max_hp, self.hp + shield)
        print(f"{self.name} memperkuat diri sebanyak {shield} HP!")
    def use_special(self, target):
        if self.energy >= 3:
            print(f"{self.name} mengaktifkan SPECIAL: memancing aggro musuh!")
            self.energy = 0

class Support(Character):
    def __init__(self, name): 
        super().__init__(name, "Support", 100, 15, 15, 20)
    def use_skill(self, target):
        print(f"{self.name} memberikan buff: +5 ATK untuk {target.name}")
        target.atk += 5
    def use_special(self, target):
        if self.energy >= 3:
            print(f"{self.name} memberi buff besar ke tim!")
            self.energy = 0

class Healer(Character):
    def __init__(self, name): 
        super().__init__(name, "Healer", 100, 20, 10, 20)
    def use_skill(self, target):
        heal = self.atk * 1.2
        target.hp = min(target.max_hp, target.hp + heal)
        print(f"{self.name} menyembuhkan {target.name} sebesar {heal} HP")
    def use_special(self, target):
        if self.energy >= 3:
            heal = self.atk * 2
            target.hp = min(target.max_hp, target.hp + heal)
            print(f"{self.name} menggunakan SPECIAL Heal ke {target.name} sebesar {heal} HP!")
            self.energy = 0

class Debuffer(Character):
    def __init__(self, name): 
        super().__init__(name, "Debuffer", 90, 18, 10, 22)
    def use_skill(self, target):
        print(f"{self.name} menurunkan DEF {target.name} sebesar 5!")
        target.defense = max(0, target.defense - 5)
    def use_special(self, target):
        if self.energy >= 3:
            print(f"{self.name} melemahkan ATK {target.name} sebesar 5!")
            target.atk = max(0, target.atk - 5)
            self.energy = 0

# Pool karakter
CHARACTERS_POOL = [
    DPS("Ragna"),
    SubDPS("Zeke"),
    Tank("Barik"),
    Support("Sera"),
    Healer("Mika"),
    Debuffer("Nox")
]