class Weapon:
    def __init__(self, name, atk_bonus=0, spd_bonus=0):
        self.name = name
        self.atk_bonus = atk_bonus
        self.spd_bonus = spd_bonus


class ItemSet:
    def __init__(self, name, atk_bonus=0, def_bonus=0, spd_bonus=0):
        self.name = name
        self.atk_bonus = atk_bonus
        self.def_bonus = def_bonus
        self.spd_bonus = spd_bonus


# Pool Senjata dan Item Set yang bisa dipilih
WEAPON_POOL = [
    Weapon("Crimson Blade", atk_bonus=10, spd_bonus=0),
    Weapon("Storm Spear", atk_bonus=5, spd_bonus=10),
    Weapon("Dragon Gauntlet", atk_bonus=8, spd_bonus=2),
]

ITEM_SETS = [
    ItemSet("Berserker's Soul", atk_bonus=5, def_bonus=0, spd_bonus=5),
    ItemSet("Fortress Wall", atk_bonus=0, def_bonus=10, spd_bonus=0),
    ItemSet("Swift Boots", atk_bonus=3, def_bonus=2, spd_bonus=7),
]