from Core.boss import InfernalBeast, ToxicSerpent, VoidReaper

class Stage:
    def __init__(self, name, description, boss_cls):
        self.name = name
        self.description = description
        self.boss_cls = boss_cls

    def get_boss(self):
        return self.boss_cls()

# Dictionary STAGES
STAGES = {
    "Flame Cavern": Stage(
        name="Flame Cavern",
        description="Gua api tempat tinggal makhluk infernal.",
        boss_cls=InfernalBeast
    ),
    "Poison Marsh": Stage(
        name="Poison Marsh",
        description="Rawa beracun yang berisi ular mematikan.",
        boss_cls=ToxicSerpent
    ),
    "Void Abyss": Stage(
        name="Void Abyss",
        description="Kedalaman gelap di mana kekacauan mengintai.",
        boss_cls=VoidReaper
    )
}